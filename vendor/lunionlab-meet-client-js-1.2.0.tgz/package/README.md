# @lunionlab/meet-client-js

SDK client web pour **lunion.meet** : connexion au SFU, publication et abonnement des pistes
média via `RTCPeerConnection` **standard** (offer/answer sur WebSocket). Framework-agnostique,
sans dépendance runtime.

> **1.0.0** : la classe cliente s'appelle **`LunionMeetClient`**, sur `RTCPeerConnection` **standard**.
> Depuis 0.1.x, `SfuClient`/`loadDevice`/`createSendTransport`/`produce` sont remplacés par
> `LunionMeetClient`. Voir « Migration » ci-dessous.

```ts
import { LunionMeetClient } from "@lunionlab/meet-client-js";

const client = new LunionMeetClient(
  { url: "wss://meet.lunion-lab.com/sfu", iceServers: [{ urls: "stun:stun.l.google.com:19302" }] },
  {
    onWelcome: ({ selfId, peers }) => console.log("connecté", selfId, peers.length, "pairs"),
    onPeerJoined: ({ peerId, name }) => console.log("arrivée", name),
    // Piste distante : `streams[0].id` = id du pair source. `onTrackMeta` distingue cam / écran / micro.
    onTrack: (track, streams, _receiver, _mid) => attachToVideoElement(streams[0], track),
    onTrackMeta: ({ mid, peerId, source }) => console.log(peerId, source), // "cam" | "mic" | "screen"
  },
);

// Résout le `welcome` (après admission si salle d'attente). `token` émis côté backend par
// @lunionlab/meet-server-sdk ; sans token = mode ouvert (hôte + salle d'attente).
const welcome = await client.connect("reunion-1", "Awa", /* cid */ undefined, token);

// Publier caméra (simulcast auto) + micro
await client.publishCamera();
await client.publishMic();
```

## Nouveautés 1.2.0

- **Partage d'écran first-class** : `publishScreen(opts?)` fait tout (getDisplayMedia, piste
  dédiée en couche unique haut débit, `contentHint="detail"`, codec H264 par défaut, étiquetage
  `source: "screen"`, arrêt automatique quand l'utilisateur stoppe depuis le bandeau du navigateur).
  `stopScreenShare()` et le getter `screenSharing` complètent l'API. `opts.audio = true` capture et
  publie aussi le **son système/onglet** (piste étiquetée `"screen-audio"` ; support navigateur variable).
- **Le partage survit à la reconnexion** : `publishTrack` mémorise désormais la `source` de la piste
  et le SDK la **ré-étiquette** après reconnexion. Auparavant, un écran re-publié après une coupure
  réseau réapparaissait en « caméra » chez les pairs.

## Nouveautés 1.1.0

- **Reconnexion réseau automatique** (option `reconnect`, activée par défaut) : sur coupure d'une
  session **établie** (bascule wifi/4G, veille, perte de porteuse), le client ré-ouvre le WebSocket,
  reconstruit le `RTCPeerConnection` et **re-publie ses pistes**, en réutilisant le `cid` pour être
  ré-admis. Handlers `onReconnecting(attempt)` / `onReconnected`. Un échec de connexion **initiale**
  rejette toujours `connect()`. Le SFU embarquant une copie générée de ce client, l'app web
  first-party en bénéficie aussi.
- **`unpublishTrack(track)`** : cesse de publier une piste (ex. arrêt du partage d'écran) et la
  retire de la re-publication de reconnexion.

## API essentielle

- `new LunionMeetClient({ url, iceServers? }, handlers?)`
- `connect(room, name, cid?, token?): Promise<LunionMeetWelcome>`
- `publishCamera(constraints?, { codec? })`, `publishMic()`,
  `publishTrack(track, stream, encodings?, codec?, source?)` (bas niveau).
  `codec` est un mimeType préféré, ex. `"video/H264"` (accélération matérielle mobile et Safari), depuis la **0.3.0**.
  `source` (depuis la **1.2.0**) étiquette la piste (`"screen"`, `"screen-audio"`…) **et survit à la
  reconnexion** — préférez-le à un `setTrackSource` manuel.
- `publishScreen(opts?: ScreenShareOptions)` — `{ video?, audio?, maxBitrate?, codec? }` —, `stopScreenShare()`, getter `screenSharing`
  (**1.2.0**) : partage d'écran clé en main, son système optionnel. Voir
  [docs/SCREEN-SHARE-NATIVE.md](https://github.com/LUNION-LAB-ORG/lunionmeet/blob/main/docs/SCREEN-SHARE-NATIVE.md) pour le mobile (config native requise).
- `setTrackSource(mid, "screen")` : étiquetage bas niveau d'une piste, relayé aux pairs via
  `onTrackMeta`. Utile seulement si vous publiez la piste vous-même sans passer `source`.
- `startRecording(peerId?)`, `stopRecording(recordingId?)` (modérateur)
- Actions plan de contrôle : chat/réaction, salle d'attente (admit/deny), modération, rôles
- Handlers : `onWelcome`, `onTrack`, `onTrackMeta`, `onPeerJoined/Left`, `onChat`, `onReaction`,
  `onWaiting`/`onJoinRequest`, `onRecordingStatus`, `onRoomFull`, `onProducerActive`, `onIceStateChange`, `onClose`…

**Dynacast (0.3.0+)** : quand vous êtes seul (aucun abonné à vos pistes), le SDK **coupe
automatiquement l'upload vidéo** à la source et le reprend dès qu'un pair s'abonne, pour une économie
d'uplink transparente. État exposé via `producerActive` et le handler `onProducerActive(active)`.

Le SFU parle **SDP offer/answer standard** sur `/ws` : aucune notion de `rtpCapabilities`,
`createWebRtcTransport` ou `produce/consume`. Le token (via le sous-protocole `lunion.token.<JWT>`,
hors URL) applique les droits `canPublish` / `canSubscribe` / `roomAdmin`… côté SFU.

Chiffrement de bout en bout (optionnel) : `E2eeTransformer` (AES-GCM par frame, SFU aveugle).

## Migration depuis 0.1.x

| Avant (≤ 0.1.x) | Après (1.0.0) |
|---|---|
| `new SfuClient(handlers, url)` | `new LunionMeetClient({ url }, handlers)` |
| `connect({ room, name, token })` | `connect(room, name, cid?, token?)` |
| `loadDevice(welcome.rtpCapabilities)` | *(supprimé, RTCPeerConnection standard)* |
| `createSendTransport()` / `createRecvTransport()` | *(supprimé)* |
| `produce(track, "camera")` | `publishCamera()` / `publishMic()` |
| `onNewProducer` → `subscribe(id)` | `onTrack(track, streams, …)` (abonnement auto) |

Un client **0.1.x n'est plus compatible** avec le SFU actuel : mettez à jour vers la **1.0.0**
(déployez le SFU à jour avant les clients).
