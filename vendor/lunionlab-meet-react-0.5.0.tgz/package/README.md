# @lunionlab/meet-react

Hooks et composants React pour **lunion.meet**, au-dessus de `@lunionlab/meet-client-js`.

```tsx
import { useLunionRoom, VideoTrack } from "@lunionlab/meet-react";

function Room({ token }: { token: string }) {
  const { localStream, participants, cameraEnabled, toggleCamera, toggleMic, leave } =
    useLunionRoom({
      sfuUrl: "wss://exemple.com/sfu",
      room: "reunion-1",
      name: "Awa",
      token, // émis côté backend par @lunionlab/meet-server-sdk
    });

  return (
    <div>
      <VideoTrack stream={localStream} muted className="w-48" />
      {participants.map((p) => (
        <div key={p.id}>
          <VideoTrack stream={p.stream} className="w-48" />
          <span>{p.name}</span>
        </div>
      ))}
      <button onClick={toggleCamera}>{cameraEnabled ? "Couper" : "Activer"} caméra</button>
      <button onClick={toggleMic}>Micro</button>
      <button onClick={leave}>Quitter</button>
    </div>
  );
}
```

Le hook gère la connexion, la publication caméra/micro et l'abonnement
automatique aux pistes des autres participants. Sans `token`, le mode ouvert
(salle d'attente / hôte) s'applique.

## Nouveautés 0.4.0

`useLunionRoom` expose désormais **tout le plan de contrôle** (au niveau des SDK mobiles) :

- **Reconnexion réseau automatique** (option `reconnect`) — coupure d'une session établie ; statut `"reconnecting"`.
- **Réception de la modération** appliquée localement (`autoApplyModeration`, `onModerated`).
- **Chat / réactions / présence** : `sendChat`/`sendReaction`/`updateState` + `onChat`/`onReaction`/`onPeerState`.
- **Contrôle hôte** : `isHost`, `admit`/`deny`/`moderate`/`setRole`/`transferHost`, `onJoinRequest`.
- **Locuteur actif** (`activeSpeaker`), **enregistrement** (`startRecording`/`stopRecording`, `onRecordingStatus`).
- **Partage d'écran** (`shareScreen`/`stopScreenShare`), **mode récepteur pur** (`receiveOnly`).
- **Scalabilité** : `setSubscribed` (virtualisation de grille) + `setVideoLayerPolicy` (qualité par couche).

Voir le [CHANGELOG](./CHANGELOG.md). Tout est rétro-compatible : l'API existante est inchangée.
